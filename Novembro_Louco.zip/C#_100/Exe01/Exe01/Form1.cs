﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exe01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int tempodigitado = int.Parse(textBox1.Text);
            int hora = tempodigitado / 3600;
            int minutos = (tempodigitado % 3600) / 60;
            int segundos = tempodigitado % 60;
            label2.Text = hora + ":" + minutos + ":" + segundos;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
