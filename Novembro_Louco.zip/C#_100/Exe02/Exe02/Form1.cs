﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exe02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string  n1 = textBox1.Text;
            string n2 = textBox2.Text;
            string n3 = textBox3.Text;
            if ( float.TryParse(n1, out float n1f) && float.TryParse(n2, out float n2f) && float.TryParse(n3, out float n3f))
            {

            float media = (n1f + n2f + n3f) / 3;
            label4.Text = "A sua media é de : " + media;
            }
            else
            {
                MessageBox.Show("Dados invalidos","Aviso",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
        }
    }
}
