﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exe5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string op = textBox1.Text.Replace(" ", "");
            string a = textBox2.Text.Replace(" " , "") ;
            string b = textBox3.Text.Replace(" " ,"");

            if(float.TryParse(a, out float n1) && float.TryParse(b, out float n2) && ! string.IsNullOrWhiteSpace(op))
            {
                if (op == "+")
                {
                    float resultado = n1 + n2;
                    label2.Text = "Resultado: " + resultado;

                }
                if (op == "-")
                {
                    float resultado = n1 - n2;
                    label2.Text = "Resultado: " + resultado;

                }
                if (op == "*")
                {
                    float resultado = n1 * n2;
                    label2.Text = "Resultado: " + resultado;

                }
                if (op == "/" &&  n2>0)
                {
                    float resultado = n1 / n2;
                    label2.Text = "Resultado: " + resultado;

                }
            }
            else
            {
                MessageBox.Show("Dados fornecidos inválidos");
            }
            
        }

    }
}
