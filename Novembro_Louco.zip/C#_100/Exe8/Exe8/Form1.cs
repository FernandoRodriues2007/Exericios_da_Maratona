﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exe8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for(int i = 1000; i <= 9999; i++)
            {
                int pp = i / 100;
                int sp = i % 100;
                int resultado = (pp + sp) * (pp + sp);
                if(resultado == i)
                {
                    listBox1.Items.Add(resultado);
                }
            }
        }
    }
}
