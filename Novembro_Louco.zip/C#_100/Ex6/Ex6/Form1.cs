﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        static float somar(float s)
        {
            float soma = 0;

            for (int i = 0; i < s + 1; i++)
            {
                soma += i;
            }
            return soma;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text.Replace(" ", "");
            
            if(float.TryParse(a, out float n))
            {

                 
                label2.Text = "Resultado : " + somar(n);
            }
        }
    }
}
