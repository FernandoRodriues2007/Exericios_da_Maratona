﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exe04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;
            string b = textBox2.Text;
            string c = textBox3.Text;
            if(float.TryParse(a, out float n1) && float.TryParse(b, out float n2) && float.TryParse(c, out float n3))
            {
                float maior = Math.Max(n1,Math.Max( n2, n3));
                float menor = Math.Min(n1, Math.Min(n2, n3));
                float intermedio = (n1 + n2 + n3) - (maior + menor);

                MessageBox.Show("Maior número " + maior + "; Intermediário " + intermedio + ";  Menor número " + menor);
                
            }
            else
            {
                MessageBox.Show("Preencha os campos corretamente ");
            }
        }
    }
}
