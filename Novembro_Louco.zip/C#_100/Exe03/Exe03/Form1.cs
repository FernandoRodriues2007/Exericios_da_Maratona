﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exe03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string n1 = textBox1.Text;
            string n2 = textBox2.Text;
            string n3 = textBox3.Text;
            if(int.TryParse(n1,out int n1a) && int.TryParse(n2, out int n2a) && int.TryParse(n3, out int n3a))
            {
               if(n1a + n2a >n3a && n3a + n1a > n2a && n2a + n3a > n1a)
                {
                    if(n1a == n2a && n2a == n3a)
                    {
                        MessageBox.Show("Triângulo Equilátero");
                    }
                    if (n1a == n2a && n2a != n3a || n2a == n3a && n3a != n1a || n1a == n3a && n3a != n2a)
                    {
                        MessageBox.Show("Triângulo Isósceles");
                    }
                    else
                    {
                        MessageBox.Show("Triângulo Escaleno");

                    }
                }
                else
                {
                    MessageBox.Show("Não da para formar um Triângulo com os dados fornecidos");
                }
            }
            else
            {
                MessageBox.Show("Dados Inválidos");
            }
        }
    }
}
